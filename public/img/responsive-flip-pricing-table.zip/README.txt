A Pen created at CodePen.io. You can find this one at http://codepen.io/shaneheyns/pen/OPWGry.

 Responsive Flip Pricing Table to view month or year price.