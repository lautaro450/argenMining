$( ".title" ).click(function() {
  $(".content").slideToggle();
});