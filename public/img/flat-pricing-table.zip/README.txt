A Pen created at CodePen.io. You can find this one at https://codepen.io/andytran/pen/LJFeg.

 A simple flat pricing table with jQuery that enables the content to slide down onClick.